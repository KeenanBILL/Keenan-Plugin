<?php

echo "This removes the admin bar on Wordpress edit mode, deactivate to edit again";